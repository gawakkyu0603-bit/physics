# Consistency Audits of Observer-Separated Open Dynamics in 2D Dilaton Gravity

**Manuscript:** *Consistency Audits of Observer-Separated Open Dynamics in 2D Dilaton Gravity: KMS Covariance, Non-Gaussian JT Fluctuations, and Chiral-Horizon Obstructions*  
**Author:** Yohtaro Soga (with AI research assistance explicitly disclosed in the manuscript)  
**Date:** November 27, 2026

This self-contained project directory contains the complete LaTeX source and compiled PDF of Paper 2 (**34 pages**, **84 cited references**, **4 vector PDF figures**), its **Lean 4.36.0 / Mathlib4** formalization (**34 machine-checked public declarations**, zero `sorry`, standard axioms only), and its deterministic **Python** verification suite (**F1–F6**, **258 recorded scientific numeric fields** across F1–F6, seed `20261127`, regenerating all 4 vector PDF figures).

> **Epistemic boundary and three-way originality classification:** Paper 2 explicitly relaxes Paper 1's strict self-perspective BPS constraint ($[L_k,H]=0$) to Layer 1 open systems and separates: (1) **directly overlapping and inherited prior art** attributed at equation level (SK/Feynman–Vernon/Wu–Lee, Davies/detailed balance/Evans–Frigerio/unitary Markov dilations/$\chi^2$/Chetrite–Mallick/Horowitz–Sagawa, Wiseman–Diósi unravelings & Wiseman–Jones–Doherty steering, Bernard–Doyon CFT counting statistics & exchange symmetry, Gaikwad et al. SYK–FV Schwarzian, Wilson-Gerow et al. warm horizons, Sperling–Vogel phase-diffused squeezed states, Maldacena–Susskind/Louko/Sanders/Ho et al. horizon models, 4D greybody asymptotics, Gisin/Frauchiger–Renner/Bong et al., non-isometric codes/Petz), (2) the **Paper 1 (OSTQD) baseline** (including §2 Remarks (ii)–(iii)), (3) **Paper 2's three-way contributions** — **(A) OSTQD adaptations & conditional applications**, **(B) focused analytical additions** (Proposition 3: smooth-band tempered distribution $\Delta W_J^{\mathrm{raw}}\in\mathcal{S}'(\mathbb{R}^2)$, degree-$-2$ homogeneity bound $c_{00}\ge c_{0,\min}>0$, and PSD-jet high-gap floor; Proposition 2: closed-form frozen-coefficient Bernard–Doyon cumulants $K_n(u)$, fixed-BD three-tier equilibrium $K_4$ comparison $0.5/1.5/1.0$, and rational factorization of $\mathcal{H}_{\mathrm{KM}}(E,p)$), and **(C) 34-declaration Lean + F1–F6 negative-control verification**, and (4) **explicit scope limits & open nonperturbative problems**.

---

## Main Results and Verification Index

| Result | Exact scope & physical content | Sources and verification |
| --- | --- | --- |
| **Theorem 3 & Propositions 3–4: Bosonic ODE, Chiral-Horizon Smooth-Band Point-Contact Floor & Number-Projective Single-Shot Scope** | Credits Sperling–Vogel (2012) for the phase-diffused squeezed family while formalizing arbitrary-$N$ `HasDerivAt` ODEs and $\mathcal{O}(Nq^N)$ remainders; **Proposition 3** proves $\Delta W_J^{\mathrm{raw}}\in\mathcal{S}'(\mathbb{R}^2)$ for smooth compact $\Gamma\in C_c^\infty((0,\infty))$, simultaneous $\epsilon^{-2}$ non-Hadamard breakdown, UV-finite raw UDW turning negative at large gap ($-A/\Omega^2$), exact degree-$-2$ bound $c_{00}\ge c_{0,\min}(\Gamma,s)>0$ (with numerically evaluated witness $-F_0(a_*)\approx 0.00197949$ at $a_*=2.1501$), and a PSD-jet lemma enforcing a non-decaying high-gap excitation floor for every positive-type finite-order point-contact extension at $(0,0)$; **Proposition 4** proves the outcome-uniform floor $2\omega n_{\mathrm{BE}}>0$ for the exterior number-projective instrument (contrasted with continuous phase-unitary unravelings) and exact $[P_A,P_B]\neq 0$ scope (distinguishing non-selective no-signaling from steering and observer-separated Layer-2 design postulates). | [paper/main.pdf](paper/main.pdf) §5, `Theorem3_HorizonHadamard.lean` (5), Suite F4, [Fig. 3](paper/figures/fig3_horizon_hadamard_udw.pdf). |
| **Theorem 2 & Proposition 2: Two-Tiered Ward Obstruction, Frozen-Coefficient Bernard–Doyon JT Cumulants & Three-Tier Equilibrium Comparison** | Separates mean conservation from zero diffusion (Lean 3-level counterexample) and parameter-free JT backreaction from $g^2$-dependent canonical $\omega/2$ outgoing chiral current rates (with two-bath $\omega/2$ non-KMS contrast); derives closed-form evaporating cumulants $K_n(u)$ ($n\ge 2$) for the linearized-drift, saddle-frozen additive Bernard–Doyon closure (audited via exact-step Gaussian & zero time-discretization bias $10^5$-path compound-Poisson MC, noting explicitly that restoring state-dependent evaporation feedback modifies the leading third cumulant); compares three equilibrium closures sharing fixed Bernard–Doyon coefficients ($K_4/\kappa_4^{\mathrm{can}}=0.5, 1.5, 1.0$) and expresses Bernard–Doyon exchange symmetry as a rational factorization of $\mathcal{H}_{\mathrm{KM}}(E,p)$ along the canonical slope $p=\beta_0-\beta(E)=V'(E)$ on $-\beta(E)<p<\beta_0$. | [paper/main.pdf](paper/main.pdf) §4, `Theorem2_WardAndFDT.lean` (9), Suite F3, [Fig. 2](paper/figures/fig2_jt_sk_evaporation_fdt.pdf). |
| **SK Normalization, Two-Kraus Unraveling Witness, Theorem 1 & Proposition 1** | Aligns $D_K=G^>+G^<=2N$ with noise action $\frac{i}{4}g^2\mathcal{O}_a D_K\mathcal{O}_a=\frac{i}{2}g^2\mathcal{O}_a N\mathcal{O}_a$ (80-level bath check, $3\times 3$ SK non-sufficiency, nonzero bath $D_R$ controls); gives an arbitrary-$d$ orthogonal Kraus unraveling witness under uncorrelated bath preparation (Remark 2); extends OSTQD $(t,s)$ commutation to thermal $\omega_k\neq 0$ jumps with Lean-checked symmetric intertwining $\mathcal{L}_{\mathrm{pair}}(SXS)=S\mathcal{L}_{\mathrm{pair}}^\dagger(X)S$ and non-commuting $\chi^2_{\beta_H}$ decay; states the Evans–Frigerio Dirichlet-kernel criterion comparing quantum regression against *free-subsystem* autocorrelations $C_{\mathrm{free}}(\tau)$ (distinguished from interacting $C_{\mathrm{total}}(\tau)$ in unitary Markov dilations, Theorem 1(f)); isolates two-level Redfield CP failure; proves exact non-asymptotic Duhamel $(t,s)$ holonomy bound vs. instantaneous-stationarity relaxation-gap tracking counterexample ($\mu/\lambda_{\mathrm{rel}}\ll 1$, Proposition 1). | [paper/main.pdf](paper/main.pdf) §2–3, `OSTQD_SK/Basic.lean` (7) & `Theorem1_CovariantKMS.lean` (8), Suites F1–F2, [Fig. 1](paper/figures/fig1_covariant_kms_and_redfield.pdf). |
| **Theorem 4 & Proposition 5: Per-Port KMS Locking, Stabilized 4D Greybody Audit, Separated Benchmarks & Condition-Indexed Closed-Infall Summary** | Establishes per-port coupled ($g\neq 0$) KMS locking, near-horizon-stabilized `wrightomega` ($f=\delta/(1+\delta)$) 4D Schwarzschild scattering across $h\in\{0,\frac{1}{2},1,2\}$ + fixed-$\omega r_s$ control, replacer-channel $d_f=1$ erasure corollary $F_e=1/d_C^2$, non-TP null-state witness for non-isometric $V$, separated F6 benchmarks including $d_C=4$ intermediate bottleneck, and **Proposition 5** synthesizing condition-indexed closed-infall obstructions and an open exterior-boundary proposal without claiming a universal closed-infall no-go theorem or unique evaporation endpoint. | [paper/main.pdf](paper/main.pdf) §6, `Theorem4_NonIsometricThroat.lean` (5), Suites F5–F6, [Fig. 4](paper/figures/fig4_greybody_throat_and_nonisometric.pdf). |

---

## Quick-Start Reproduction

### 1. Numerical Verification Suites & Figures (Python)
```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python scripts/verify_paper2_sk_jt.py
```

### 2. Lean 4.36.0 Machine-Checked Proofs (WSL / Linux / macOS)
```bash
cd lean4
lake exe cache get
lake build OSTQD_SK
lake env lean OSTQD_SK/AxiomCheck.lean
```

### 3. Manuscript Compilation (TeX Live)
```bash
cd paper
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

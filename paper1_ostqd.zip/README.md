# Observer-Separated Two-Time Quantum Dynamics (OSTQD)

**Manuscript:** *Observer-Separated Two-Time Quantum Dynamics: Local Horizon Obstructions, Cross-Perspective Consistency, and Finite-Dimensional Evaporation Bounds*  
**Author:** Yohtaro Soga (with AI research assistance explicitly disclosed in the manuscript)  
**Date:** November 28, 2026

This self-contained repository contains the LaTeX source and compiled PDF (**29 pages**, **56 cited references**, **3 vector PDF figures**), the **Lean 4.36.0 / Mathlib4** formalization (**50 machine-checked audited public declarations**, zero `sorry`, zero tactic-linter warnings, standard axioms only), and the deterministic **Python** verification suite (**451 recorded scientific numeric fields**, seed `20261126`, pinned dependencies in `scripts/requirements.txt`, regenerating all 3 vector PDF figures).

> **Epistemic boundary and four-tier contribution classification:** This work strictly distinguishes:
> 1. **Conceptual Proposal, Concrete Constructions, and Formalized Synthesis** (the paradox-motivated observer-indexed $(t,s)$ formulation with explicit global-state restriction vs. autonomous subalgebra closure $[H_O,\mathcal{A}_O]\subseteq\mathcal{A}_O$ and degenerate-subspace non-Hermitian purity-increase audit; exact eigenbasis-averaged variance-injection identity; two-sided $[H_A,H_B]=0$ vs. exterior-local $\gamma_{\mathrm{loc}}=8\omega^2 n_{\mathrm{FD}}(1-n_{\mathrm{FD}})$ and 4D fermionic saturation/reduced-state invariance; constructive CPTP Choi attainment of the entire shaded joint-channel region [upper curve, lower curved/flat boundaries, interior] + causal projective shared-record readout contrasted with finite-$s$ weak measurement; finite-width energy-window compatibility with non-stationary $t$-evolution; and the 50-declaration Lean + 451-field Python audit);
> 2. **Inherited Tools and Specializations of Prior Art** explicitly attributed at equation level (GKSL/BPS, Kay–Kaszlikowski–Ramanathan 2009 curved singlet monogamy & **Nechita–Pellegrini–Rochette 2021** `arXiv:2106.09655` full universal asymmetric cloning region, Baumgratz–Cramer–Plenio 2014 coherence, Lidar–Chuang–Whaley 1998 DFS, Schumacher 1996, Petz 1986, Hawking 1971 area theorem, Unruh–Wald 1984, DSW 2023, and **Farber–Gour 2026** `arXiv:2610.14785` §IV Theorem 5 whose maximally mixed specialization gives Theorem 5);
> 3. **Explicit Physical Hypotheses** not derived from first principles here (causal restriction $\mathcal{A}_B=M_2(\mathbb{C})_R\otimes\mathbf{1}_L$; physical $s(\tau)$ and wavepacket/detector coupling beyond stochastic phase noise; operational rules waiving global joint extensions; identifying $\ln d_f$ with $S_{\mathrm{BH}}$ without classical side channels or radiation access);
> 4. **Open Nonperturbative Problems** (Type $\mathrm{II}_1/\mathrm{II}_\infty$ crossed-product lifts, continuum stress-energy and Hadamard regularity, general observer-separated selective instruments, microscopic derivation of $\Gamma_O$ from large-$N$ BFSS/IKKT dynamics, and emergent 4D Lorentzian geometry).

---

## Main Results and Verification Index

| Result | Exact scope and physical content | Sources and verification |
| --- | --- | --- |
| **Definition 1 & Theorem 1: Algebra Closure, BPS Immunity, and Eigenbasis-Averaged Variance** | Distinguishes global-state restriction from autonomous subalgebra closure ($[H_O,\mathcal{A}_O]\subseteq\mathcal{A}_O$, audited via a $D_2\otimes M_2$ non-closure counterexample) and non-selective dissipative evolution from pure dephasing (audited via a degenerate-subspace non-Hermitian BPS purity-increase counterexample); proves for purely dissipative GKSL generators that $\mathcal{L}^\dagger(H)=\mathcal{L}^\dagger(H^2)=0 \iff \forall k,[L_k,H]=0$, which is sufficient (not necessary, audited via amplitude damping) for $[\mathcal{L},\mathrm{ad}_H]=0$; proves $\frac{1}{d}\mathrm{Tr}\,\Gamma_{\mathcal{L}}(H,H)=\frac{1}{d}\sum_j \partial_s\mathrm{Var}_{|E_j\rangle}(H)|_{s=0}$ (distinguished from $\partial_s\mathrm{Var}_{\rho_{\mathrm{mm}}}(H)$). | [paper/main.pdf](paper/main.pdf) §§2–3, `OSTQD/Basic.lean` (2), `OSTQD/Theorem1_BPS.lean` (10), `verify_ostqd.py` |
| **Theorem 2: Local Horizon Obstructions and Exact 4D Fermionic Hawking Pair** | Proves $[H_A,H_B]=0$ globally on $M_4(\mathbb{C})$ while restricting to $\mathcal{A}_B=M_2(\mathbb{C})_R\otimes\mathbf{1}_L$ gives $\gamma_{\mathrm{loc}}=8\omega^2 n_{\mathrm{FD}}(1-n_{\mathrm{FD}})$ ($T_H>0$), unified excitation rate $2\Gamma\omega n_\sigma(1+\sigma n_\sigma)$ ($\sigma=\pm 1$), exact $s\ge 0$ fermionic ODE ($s<0$ even subdeterminant $<0$), saturation $\langle H_A\rangle_{\rho_B(\infty)}/(2\omega)=\|\rho_0-\mathcal{P}_B(\rho_0)\|_F^2=S_L(\rho_R^{\mathrm{Hawking}})$, invariance of both one-sided reduced states ($\mathrm{Tr}_L$ and $\mathrm{Tr}_R$), operational Gaussian phase-noise equivalence, and a 4D counterexample ($\gamma_{\mathrm{loc}}=2$) where $|00\rangle$ remains fixed. | [paper/main.pdf](paper/main.pdf) §3, `OSTQD/Theorem2_Horizon.lean` (16), [Fig. 1](paper/figures/fig1_horizon_heating.pdf) |
| **Theorem 3: Complete Achievable Joint Band, CPTP Choi Constructions, Marginal CPL, and Projective vs. Weak Readout** | For $d_C\ge 2$, proves both the curved upper boundary and the reverse-triangle lower boundary (plus sharp linear outer envelope $F_A+F_B\le 1+1/d_C$; cf. Kay et al. 2009 & Nechita–Pellegrini–Rochette 2021), constructs valid CPTP Choi states attaining the **entire shaded region** (upper curve $\sigma^+(x)$, lower curved boundary $\sigma^-(x)$, flat zero lower boundary via a shift measure-and-prepare channel, and all interior points via convex mixtures), proves separate-condition reversible channels $(\mathcal{E}_A,\mathcal{E}_B)$ attain $F_e=1$ each with marginal CPL on a shared factor commuting with logical operations, and constructs an ideal causal projective shared-record readout ($P(x\neq y)=0$, matching the $s\to\infty$ record limit) contrasted with finite-$s$ weak measurement ($P_{\mathrm{disagree}}=(1-\eta^2)/2 = \frac{1}{2}e^{-\Gamma s}$). | [paper/main.pdf](paper/main.pdf) §4, `OSTQD/Theorem3_CrossPerspective.lean` (10), [Fig. 2(a)](paper/figures/fig2_joint_vs_separated.pdf) |
| **Theorem 4: Parisi–Wu Purity Arrow, Spectral Pinching, and Finite-Width Energy Windows** | Proves Hermitian-jump purity monotonicity, linear-entropy Pythagorean identity $S_L(\mathcal{P}\rho)=S_L(\rho)+\|\rho-\mathcal{P}\rho\|_F^2$, exact off-diagonal block eigenvalue decay linking $e^{s\mathcal{L}}\to\mathcal{P}$ for sector-separating commuting jumps, and non-stationary intra-window $t$-evolution with exact $s$-invariance inside a finite-width energy window $\Pi_{\mathrm{win}}$. | [paper/main.pdf](paper/main.pdf) §5, `OSTQD/Theorem4_DoubleUncertainty.lean` (6), [Fig. 3](paper/figures/fig3_matrix_evaporation.pdf) |
| **Theorem 5 & Numerical Models: Unassisted Bottleneck Bound (Special Case of Farber–Gour 2026) and Benchmarks** | Gives an elementary Lean-verified Kraus proof (both $d_f\le d_C$ and $d_f>d_C$ attainment) of $F_e(\mathcal{R}\circ\mathcal{E})\le\min(1,d_f^2/d_C^2)$ (the $\rho=\mathbf{1}_{d_C}/d_C$ specialization of Farber–Gour 2026 §IV Thm. 5), audits its no-classical-side-channel assumption via a $(d_C=4,d_f=2)$ 1-bit flag counterexample ($F_e=1/2>1/4$), presents a two-window $N=8$-qubit $t$-encoding/$s$-invariance compatibility demonstration (with inter-window $s$-decay and $d_C=4$ intermediate-bottleneck contrasts), and audits a companion fixed-cutoff $SU(2)$ Yang–Mills Galerkin benchmark ($N_{\mathrm{cut}}=3,4$). | [paper/main.pdf](paper/main.pdf) §§5–6, `OSTQD/Theorem5_Bottleneck.lean` (6), [Fig. 2(b)](paper/figures/fig2_joint_vs_separated.pdf), [Fig. 3](paper/figures/fig3_matrix_evaporation.pdf) |

---

## Quick-Start Reproduction

### 1. Python Numerical Suite & Figures (Pinned Environment)
Install the exact tested dependencies from `scripts/requirements.txt` (`Python 3.14.7`, `numpy==2.4.2`, `scipy==1.17.1`, `matplotlib==3.10.8`) and run:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python scripts/verify_ostqd.py
```

This runs all assertions deterministically (seed `20261126`), regenerates `docs/numerical_verification.json` (451 scientific numeric fields), and regenerates all three vector PDF figures in `paper/figures/`.

### 2. Lean 4.36.0 Formal Proofs (Linux / macOS / WSL)
From `lean4/` (with `elan` installed):

```bash
bash verify_lean.sh
```

Or step-by-step:

```bash
lake exe cache get
lake build OSTQD
lake env lean OSTQD/AxiomCheck.lean
```

Complete kernel verification output is archived in `lean4/VERIFICATION_LOG.txt`.

### 3. Manuscript Compilation (TeX Live)
From `paper/` (pre-built `main.bbl` is included for arXiv submission):

```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

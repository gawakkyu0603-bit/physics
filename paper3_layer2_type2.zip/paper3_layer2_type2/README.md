# Observer-Separated Selective Instruments, Born-Weighted Branching, and Non-Isometric Pullback Defects in Type II Gravitational Algebras

Self-contained research archive (`paper3_layer2_type2/`) continuing our preceding finite-dimensional OSTQD (`Soga2026OSTQD`, provisional PDF: https://gawakkyu0603-bit.github.io/physics/downloads/ostqd.pdf) and 2D dilaton-gravity Schwinger–Keldysh (`Soga2026OSTQDSK`, provisional PDF: https://gawakkyu0603-bit.github.io/physics/downloads/ostqd-sk-jt.pdf) studies into Layer 2 selective instruments, semifinite Type $\mathrm{II}_1/\mathrm{II}_\infty$ Segal-entropy branch splitting, uniformly sharp non-isometric Born-weight pullback bounds, strictly causal sequential evaporation vs. postselected dictionaries, and a five-property causal/linear inter-branch coupling audit.

## Directory Layout

- `paper/` — LaTeX source (`main.tex`), verified bibliography (`references.bib`, pre-built `main.bbl`, 71 cited references), compiled PDF (`main.pdf`, 31 pages, Abstract strictly on Page 1, 0 warnings), and 4 vector PDF figures (`figures/`).
- `lean4/` — Independent Lean 4.36.0 + Mathlib4 formalization library `OSTQD_Layer2` (61 audited theorem declarations, standard 3 axioms only, 0 forbidden tokens, 0 tactic/linter warnings, archived log in `VERIFICATION_LOG.txt`; see `lean4/README.md` for sequential-module build notes on memory-constrained native Windows).
- `scripts/` — Deterministic Python verification and figure-generation suite (`verify_paper3_layer2_type2.py`, seed `20261128`).
- `docs/` — Mathematical blueprint (`THEORY_BLUEPRINT.md`) and categorized numerical audit output (`numerical_verification.json`, 329 scientific numeric fields across G1–G5).
- `PRIOR_ART.md` — Equation/theorem-level primary-literature attribution (including Araki 1977, Harada–Kosaki 2010, Kantorovich 1948 / Gustafson 1968, Oas et al. 2014, Beckman et al. 2001, Chiribella et al. 2009, Watrous 2018, DeWolfe–Higginbotham 2023, Longo–Witten 2023) and three-way contribution classification.
- `VERIFICATION.md` — Explicit trust boundary separating Lean 4 machine-checked finite-dimensional theorems (at exact proposition granularity), finite-dimensional analytical bridges outside Lean, the six concrete missing Mathlib4 v4.36.0 continuum libraries, analytical proofs, and numerical audits.
- `paper3_layer2_type2.zip` — Clean, self-contained submission archive (CRC-verified; excludes internal revision notes).

## Quick Reproduction

1. **Python verification & figures:**
   ```bash
   OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python scripts/verify_paper3_layer2_type2.py
   ```
2. **Lean 4.36.0 kernel verification (from `lean4/`):**
   ```bash
   lake exe cache get
   lake build OSTQD_Layer2
   lake env lean OSTQD_Layer2/AxiomCheck.lean
   ```
3. **LaTeX manuscript build (from `paper/`):**
   ```bash
   pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
   ```
